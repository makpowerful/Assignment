package pageObjects;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.github.javafaker.Faker;
import com.github.javafaker.PhoneNumber;

import resources.ExcelData;
import resources.base;

public class accountPO extends base{
	WebDriver driver;

	private String lnk_Account_xpath = "//nav[@aria-label]//a[@title='Accounts']";
	private String btn_New_xpath = "//span[text()='Accounts'][contains(@class,'small')]/following::a[@title='New']";
	private String txt_AccountName_xpath = "(//h2[text()='New Account']/following::label[text()='Account Name']/following::input)[1]";
	private String lbl_AccountName_xpath = "(//h2[text()='New Account']/following::label[text()='Account Name'])[1]";
	private String txt_PhoneNo_xpath = "(//h2[text()='New Account']/following::label[text()='Phone']/following::input)[1]";
	private String txt_Fax_xpath = "(//h2[text()='New Account']/following::label[text()='Fax']/following::input)[1]";
	private String msg_ToastMessge_xpath = "//span[contains(@class,'toast')]";
	
	private String btn_Save_xpath = "//h2[text()='New Account']/following::button[text()='Save']";
	static Faker faker = new Faker();
    static int randomNum = ThreadLocalRandom.current().nextInt(1000, 10000 + 1);
    static String firstName = faker.name().firstName().replaceAll("'","");
	
	
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	
	//Declaring Constructor
	public accountPO(WebDriver driver) {
		this.driver=driver;
	}
	
	//**************************************************Kalam Methods******************************************************
    
	//@Author : Kalam
    //Create Account
    public void createAccount() throws InterruptedException {
        visibleText(By.xpath(lnk_Account_xpath));
        jsClick(driver.findElement(By.xpath(lnk_Account_xpath)));
        visibleText(By.xpath(btn_New_xpath));
        jsClick(driver.findElement(By.xpath(btn_New_xpath)));
        visibleText(By.xpath(txt_AccountName_xpath));
        driver.findElement(By.xpath(txt_AccountName_xpath)).sendKeys(firstName);
        Thread.sleep(300);
        jsClick(driver.findElement(By.xpath(lbl_AccountName_xpath)));
        driver.findElement(By.xpath(txt_PhoneNo_xpath)).sendKeys("1122331122");
        driver.findElement(By.xpath(txt_Fax_xpath)).sendKeys("1122331122");
        visibleText(By.xpath(btn_Save_xpath));
        jsClick(driver.findElement(By.xpath(btn_Save_xpath)));
    }

    //Toast Message creation of Account
    public boolean toastMessage() throws InterruptedException {
        visibleText(By.xpath(msg_ToastMessge_xpath));
        return driver.findElement(By.xpath(msg_ToastMessge_xpath)).isDisplayed();
        
    }
    
    //Retrieving Account
    public void openCreatedAccount() {
        visibleText(By.xpath(lnk_Account_xpath));
        jsClick(driver.findElement(By.xpath(lnk_Account_xpath)));
        visibleText(By.xpath("//span[text()='Accounts'][contains(@class,'small')]/following::tbody//th//a[text()='"+firstName+"']"));
        jsClick(driver.findElement(By.xpath("//span[text()='Accounts'][contains(@class,'small')]/following::tbody//th//a[text()='"+firstName+"']")));
    }
    
    //Update Account
    public void updateAccountPhoneNo(String num) {
        visibleText(By.xpath("//div[contains(@class,'NameWithHierarchyIcon')]/lightning-formatted-text[text()='"+firstName+"']/following::a[@data-tab-value][text()='Details']"));
        jsClick(driver.findElement(By.xpath("//div[contains(@class,'NameWithHierarchyIcon')]/lightning-formatted-text[text()='"+firstName+"']/following::a[@data-tab-value][text()='Details']")));
        visibleText(By.xpath("(//div[contains(@class,'NameWithHierarchyIcon')]/lightning-formatted-text[text()='"+firstName+"']/following::span[text()='Account Name']/following::button[contains(@class,'edit')])[1]"));
        jsClick(driver.findElement(By.xpath("(//div[contains(@class,'NameWithHierarchyIcon')]/lightning-formatted-text[text()='"+firstName+"']/following::span[text()='Account Name']/following::button[contains(@class,'edit')])[1]")));
        visibleText(By.xpath("(//div[contains(@class,'NameWithHierarchyIcon')]/lightning-formatted-text[text()='"+firstName+"']/following::label[text()='Phone']/following::input)[1]"));
        driver.findElement(By.xpath("(//div[contains(@class,'NameWithHierarchyIcon')]/lightning-formatted-text[text()='"+firstName+"']/following::label[text()='Phone']/following::input)[1]")).clear();
        driver.findElement(By.xpath("(//div[contains(@class,'NameWithHierarchyIcon')]/lightning-formatted-text[text()='"+firstName+"']/following::label[text()='Phone']/following::input)[1]")).sendKeys(num);
        jsClick(driver.findElement(By.xpath("//div[contains(@class,'NameWithHierarchyIcon')]/lightning-formatted-text[text()='"+firstName+"']/following::label[text()='Phone']")));
        visibleText(By.xpath("(//div[contains(@class,'NameWithHierarchyIcon')]/lightning-formatted-text[text()='"+firstName+"']/following::label[text()='Fax']/following::input)[1]"));
        driver.findElement(By.xpath("(//div[contains(@class,'NameWithHierarchyIcon')]/lightning-formatted-text[text()='"+firstName+"']/following::label[text()='Fax']/following::input)[1]")).sendKeys(num);
        jsClick(driver.findElement(By.xpath("//div[contains(@class,'NameWithHierarchyIcon')]/lightning-formatted-text[text()='"+firstName+"']/following::label[text()='Fax']")));
        visibleText(By.xpath("//div[contains(@class,'NameWithHierarchyIcon')]/lightning-formatted-text[text()='"+firstName+"']/following::button[text()='Save']"));
        jsClick(driver.findElement(By.xpath("//div[contains(@class,'NameWithHierarchyIcon')]/lightning-formatted-text[text()='"+firstName+"']/following::button[text()='Save']")));
    }
    
    public boolean verifyPhoneNoChange(String num) throws InterruptedException {
        Thread.sleep(1500);
        String[] fullphonenoString= driver.findElement(By.xpath("(//div[contains(@class,'NameWithHierarchyIcon')]/lightning-formatted-text[text()='"+firstName+"']/following::span[text()='Phone']/following::a)[1]")).getAttribute("href").split(":");
        String actualNumberString = fullphonenoString[1];
        if(actualNumberString.equalsIgnoreCase(num)) {
            return true;
        }
        else {
            return false;
        }
    }
    
    //Delete Account
    public void deleteAccount() throws InterruptedException {
        Thread.sleep(1500);
        visibleText(By.xpath(lnk_Account_xpath));
        jsClick(driver.findElement(By.xpath(lnk_Account_xpath)));
        visibleText(By.xpath("//span[text()='Accounts'][contains(@class,'small')]/following::tbody//th//a[text()='"+firstName+"']"));
        Thread.sleep(1000);
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(By.xpath("//a[text()='"+firstName+"']/following::span[@class='slds-icon_container slds-icon-utility-down']"))).build().perform();
        jsClick(driver.findElement(By.xpath("//a[text()='"+firstName+"']/following::span[@class='slds-icon_container slds-icon-utility-down']")));
        visibleText(By.xpath("//a[@title='Delete']"));
        jsClick(driver.findElement(By.xpath("//a[@title='Delete']")));
        visibleText(By.xpath("//button/span[text()='Delete']"));
        jsClick(driver.findElement(By.xpath("//button/span[text()='Delete']")));        
    }
    
    //JavaScript Click
    public void jsClick(WebElement el) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("arguments[0].click();", el);
            System.out.println("Element clicked");
        } catch (Exception e){
            System.out.println("=============================================================");
            System.out.println("Exception-jsClick(): "+e.getMessage());
            e.printStackTrace();
            System.out.println("=============================================================");
        }
    }
    
    //Explicit wait
    public boolean visibleText(By element) {
        WebDriverWait wait = new WebDriverWait(driver,10);

        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));

        System.out.println("Element is visible");
        return false;
    }

}
