package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class fileUpload {
    public WebDriver driver;
    
    private String txt_title_xpath = "//input[@name='title']";
    private String txt_description_xpath = "//input[@name='description']";
    private String btn_submit_xpath = "//button[@type='submit']";
    
    public fileUpload(WebDriver driver) {
        this.driver= driver;
    }
    
    //Site to Load
    public void launchURL(String url) {
        driver.get(url);
    }
    
    //Enter title 
    public void enterTitle(String title) {
        driver.findElement(By.xpath(txt_title_xpath)).sendKeys(title);
    }
    
    //Enter Description 
    public void enterDescription(String description) {
        driver.findElement(By.xpath(txt_description_xpath)).sendKeys(description);
    }
    
    //Add File
    public void addFile() {
        WebElement addFile = driver.findElement(By.xpath(".//input[@type='file']"));
        addFile.sendKeys(System.getProperty("user.dir")+"\\src\\main\\java\\resources\\jpg_photo.jpg");
    }
    
    //Click Submit Button
    public void clickSubmit() {
        driver.findElement(By.xpath(btn_submit_xpath)).click();
    }
    
    
}
