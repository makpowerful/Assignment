package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class timeLinePO {
    public WebDriver driver;

    public timeLinePO(WebDriver driver) {
        this.driver = driver;
    }

    // Site to Load
    public void launchURL(String url) {
        driver.get(url);
    }

    // Enter title
    public boolean validateTimelineExists(String year) {
        try {
            String headerString = driver
                    .findElement(
                            By.xpath("//div[contains(@class,'timeline-row')]//h3[contains(text(),'" + year + "')]"))
                    .getText();
            System.out.println(year + " Exists in timeline, The Header content is : " + headerString);
            return true;
        } catch (Exception e) {
            // TODO: handle exception
            System.out.println(year + " does not exist in timeline");
            return false;
        }
    }

}
