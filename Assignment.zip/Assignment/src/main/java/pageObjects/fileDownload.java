package pageObjects;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class fileDownload {
    public WebDriver driver;
    
    private String tble_title_xpath = "//th[text()='Title']/following::tr[1]//td[1]";
    private String tble_description_xpath = "//th[text()='Description']/following::tr[1]//td[2]";
    private String lnk_download_xpath = "//th[text()='Download File']/following::tr[1]//td[3]";
    
    public fileDownload(WebDriver driver) {
        this.driver= driver;
    }
    
    //Extract Title text
    public String verifyTitle() {
        visibleText(By.xpath(tble_title_xpath));
        return driver.findElement(By.xpath(tble_title_xpath)).getText();
         
    }
    
    //Extract Description text
    public String verifyDescription() {
        return driver.findElement(By.xpath(tble_description_xpath)).getText();
         
    }
    
    //Click Download option
    public void clickDownload() {
        driver.findElement(By.xpath(lnk_download_xpath)).click();
    }
    
    //Check File is present
    public boolean checkFilePresent(String expectedFileName) throws IOException, InterruptedException {
        String os = System.getProperty("os.name").toLowerCase();

        String downloadsPath = "";

        if (os.contains("win")) {
            downloadsPath = System.getenv("USERPROFILE") + "\\Downloads";
        } else if (os.contains("mac")) {
            downloadsPath = System.getProperty("user.home") + "/Downloads";
        } else if (os.contains("nix") || os.contains("nux") || os.contains("aix")) {
            downloadsPath = System.getProperty("user.home") + "/Downloads";
        }

        System.out.println("Downloads folder path: " + downloadsPath);
        File directory = new File(downloadsPath);
        FileUtils.cleanDirectory(directory);
        Thread.sleep(1000);
        File folder = new File(downloadsPath);
        File[] listOfFiles = folder.listFiles();
        boolean isFileAvailable = false;
        for (File listOfFile : listOfFiles) {
            if (listOfFile.isFile()) {
                String fileName = listOfFile.getName();
                System.out.println("File " + fileName);
                if (fileName.contains(expectedFileName)) {
                    isFileAvailable = true;
                }
            }
        }
        return isFileAvailable;
    }
    
    //Explicit wait
    public boolean visibleText(By element) {
        WebDriverWait wait = new WebDriverWait(driver,5);

        wait.ignoring(StaleElementReferenceException.class)
                .until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));

        System.out.println("Element is visible");
        return false;
    }
    
    
}
