package pageObjects;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import resources.ExcelData;
import resources.base;

public class loginPO extends base{
	WebDriver driver;

	private String txtUsernamexpath = "//input[@id='username']";
	private String txtPasswordxpath = "//input[@id='password']";
	private String btnLoginxpath = "//input[@type='submit']";
	
	
	
	ExcelData excelData = new ExcelData();
	ArrayList<String> al = new ArrayList<String>();
	
	//Declaring Constructor
	public loginPO(WebDriver driver) {
		this.driver=driver;
	}
	
	//**************************************************Kalam Methods******************************************************
    
	//@Author : Kalam
    //Site to Load
    public void launchURL(String url) {
        driver.get(url);
    }
	
	//@Author : Kalam
	//Method to enter Username
	public void enterUserName(String UN) throws InterruptedException {
		
		driver.findElement(By.xpath(txtUsernamexpath)).sendKeys(UN);
		Thread.sleep(500);
	}
	
	//@Author : Kalam
	//Method to enter Password
	public void enterPassword(String Pass) throws InterruptedException {
		
		driver.findElement(By.xpath(txtPasswordxpath)).sendKeys(Pass);
		Thread.sleep(500);
	}
	
	//@Author : Kalam
	//Method to click on Login button
	public void ClickLoginbtn() throws InterruptedException {
		
		driver.findElement(By.xpath(btnLoginxpath)).click();
		Thread.sleep(1000);
	}

    public void loginIntoAccount() throws InterruptedException {
        // TODO Auto-generated method stub
        launchURL("https://brave-panda-3h4wro-dev-ed.lightning.force.com/lightning/page/home");
        enterUserName("mak_powerful@brave-panda-3h4wro.com");
        enterPassword("Bangalore@2");
        ClickLoginbtn();
        
    }


}
