package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class graphPO {
    public WebDriver driver;

    private String grph_Table_xpath = "//*[local-name()='svg']//*[name()='g' and @class='highcharts-series-group']//*[name()='rect']";
    private String grph_Bar_xpath = "//*[local-name()='svg']//*[name()='g' and @class='highcharts-label highcharts-tooltip highcharts-color-undefined']//*[name()='text']";

    public graphPO(WebDriver driver) {
        this.driver = driver;
    }

    // Site to Load
    public void launchURL(String url) {
        driver.get(url);
    }

    // Validate Graph
    public void extractGraphDetails() throws InterruptedException {
        List<WebElement> bars = driver.findElements(By.xpath(grph_Table_xpath));
        System.out.println("Number of Bars are: "+bars.size());

        Actions actions = new Actions(driver);
        System.out.println("Details of the Graph are as follows: ");
        for (WebElement e : bars) {
            actions.moveToElement(e).perform();
            Thread.sleep(300);
            String text = driver.findElement(By.xpath(grph_Bar_xpath)).getText();
            System.out.println(text);
        }
    }

}
