package testCases;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.FalseFileFilter;

import pageObjects.*;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTDocument1;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import resources.base;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.*;

public class Practice1 extends base{
     WebDriver driver;
     final String expectedFileName = "files_";
     //files_1692353361170_jpg_photo
     //files_1692360021849_jpg_photo.jpg
     

    @BeforeTest
    public void setup() throws IOException {
        driver = InitializeBrowser();
    }
    
    @Test(enabled = true)
    public void CRUDoperations() throws AWTException, IOException, InterruptedException {
       loginPO lpo= new loginPO(driver);
       accountPO apo = new accountPO(driver);
       //Login to Salesforce to create Account
       lpo.loginIntoAccount();
       
       //Creating Account
       apo.createAccount();
       Assert.assertTrue(apo.toastMessage(),"Account Creation message is not visible");
       
       //Retrieving Account
       apo.openCreatedAccount();
       
       //Update Account
       apo.updateAccountPhoneNo("1122334455");
       Assert.assertTrue(apo.verifyPhoneNoChange("1122334455"));
       
       
       //Delete Account
       apo.deleteAccount();
       Assert.assertTrue(apo.toastMessage(),"Account deletion message is not visible");
        
    }
    
    @Test(enabled = true)
    public void FileUploadDownload() throws AWTException, IOException, InterruptedException {
        fileUpload fu = new fileUpload(driver);
        fileDownload fd = new fileDownload(driver);
        fu.launchURL("http://localhost:3030/");
        fu.enterTitle("Test 3");
        fu.enterDescription("Test 3");
        fu.addFile();
        fu.clickSubmit();
        
        String CreatedTitle = fd.verifyTitle();
        String CreatedDescription = fd.verifyDescription();
        fd.clickDownload();
        
        Assert.assertEquals("Test 3", CreatedTitle);
        Assert.assertEquals("Test 3", CreatedDescription);
        Assert.assertTrue(fd.checkFilePresent("files_"), "Downloaded document is not found");
      //div[contains(@class,'timeline-row reverse active')]//h3[contains(text(),'1952')]  
    }
    
    @Test(enabled = true)
    public void TimeLine() throws AWTException, IOException, InterruptedException {
        timeLinePO tl = new timeLinePO(driver);
        tl.launchURL("https://www.kenan-flagler.unc.edu/about/history/");
        Assert.assertTrue(tl.validateTimelineExists("2016"));
        
    }
    
    @Test(enabled = true)
    public void Graph() throws AWTException, IOException, InterruptedException {
        graphPO tl = new graphPO(driver);
        tl.launchURL("https://emicalculator.net/");
        tl.extractGraphDetails();
    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }

}
